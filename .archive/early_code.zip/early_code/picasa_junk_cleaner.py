#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
#############################################################################
 Main script for cleaning up files left behind by Picasa.

 The primary junk is a folder named .picasaoriginals/ that contains originals images
 unmodified by Picasa.  These files will cause duplicate images when the folder is
 uploaded to Google Photos (using Google Backup and Sync.

 There is another junk file named picasa.ini, but it may or may not exist.  It does not
 have any impact on Google Photos, but it will be archived with .picasaoriginals when
 possible.

 Implementation...
 1)  User inputs a starting directory (currently hardcoded, startdir).
 2)  Walk through all subfolders and store any folder that contains .picasaoriginals in
 a list named ____
 3)  Cycle through list of folders.
     3a)  If a folder has nested folders...  print message and do NOTHING.
     3b)  If a folder has the typical one level of junk, ZIP it.
 4)  Prompt user before doing batch ZIP/DELETE.
 5)  Zip and delete!

 TODO
 - add user inputs
 -   Starting directory
 -   simulation mode (no zip, no delete)
 - add option (or just small utility) to delete empty folders (only contain .picasaorig and .ini)
 - notify if there are folders that only contain .mp4, .mov, .vid, etc.


 Q:  If a .zip already exists, what happens?
 A:  Currently we use "w" which overwrites.
     Could use "a" which will append.

 Q:  What happens if trying to append same files to existing .zip?
 A:  It will store the file inside the .zip twice, with duplicate names. Not good.




#############################################################################
"""

import os
import time

from os.path import  dirname

from my_functions import countdown, countdown_in_sec, \
                         build_list_of_photo_dirs_with_junk, \
                         check_for_multiple_layers_of_junk, \
                         confirm, \
                         zip_picasaoriginals_in_, \
                         delete_picasaoriginals_in_

#def main():

# Set starting point
#startdir = "/c/Photos/2014/"
#startdir = "c:\\Photos\\2015\\"
#startdir = "c:\\Photos\\"
#startdir = "c:\\PhotosTestLayers\\"
startdir = "c:\\PhotosTest\\"
startdir = "c:\\Photos\\"
simulation_mode = True


# Other variables
photo_dirs_with_junk = []
zippy_list = []
ignore_list = []

print("\n\nThis script will cleanup junk left behind by Picasa.")
print("It cannot handle all situations, so some folders will be ignored.")
print("For those situations, *manually* go back and clean them up.")
print()
time.sleep(1)
print("...\n")


# Get list of ALL folders below starting dir that have the .picasaoriginals sub-folder
photo_dirs_with_junk = build_list_of_photo_dirs_with_junk(startdir)
#print("\nList of all photo dirs with junk:")
#print(*photo_dirs_with_junk, sep="\n", end="\n")


# Determine if any folders have multiple layers and should be skipped from ZIP/DELETE
# TODO: Handle these later sometime
print("\nChecking for multiple junk in folders and building lists")
for d in photo_dirs_with_junk:

    if check_for_multiple_layers_of_junk(d):
        ignore_list.append(d)
    elif dirname(d) in ignore_list:  # If the parent dir is already in ignore_list
        ignore_list.append(d)
    else:
        zippy_list.append(d)

# Print IGNORE list
print("\ATTENTION! These %s directories will NOT be touched because they have multiple layers." % len(ignore_list) )
if len(ignore_list) is 0:
    print("None")
else:
    print(*ignore_list, sep="\n", end="\n")


# Print CLEAN list
print("\n\nThese %s directories WILL BE cleaned of picasa junk." % len(zippy_list) )
if len(zippy_list) is 0:
    print("None")
else:
    print(*zippy_list, sep="\n", end="\n")

# Prompt user, then perform the ZIP an DELETE process
if len(zippy_list):

    # Prompt user to continue
    print("\n\n  >>> Wait!  ....  This could be dangerous...")
    print("  >>> Are you sure you want to ZIP and DELETE?")
    if confirm("Type y to continue, or n to quit:  ") is False:
        print("No worries, better safe than sorry!")
    else:
        print("Ok.  Here we go ...\n")
        countdown_in_sec(3)
        for d in zippy_list:

            if True: print("********  ", d)

            zip_picasaoriginals_in_(d, simulation_mode)
            delete_picasaoriginals_in_(d, simulation_mode)
            print()

print()




if __name__ == "__main__":
   print()