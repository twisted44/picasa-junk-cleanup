#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Restore unmodified test data to test data location for repeated testing."""

from my_functions2 import restore

restore()



if __name__ == "__main__":
    print("Executing directly")

