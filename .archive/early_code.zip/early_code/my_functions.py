# -*- coding: utf-8 -*-

"""Function definitions for picasa_junk_cleaner"""

import os
import time
from os.path import join, relpath, isdir, isfile, basename
from shutil import rmtree, copytree
from zipfile import ZipFile, ZIP_DEFLATED

keyword = ".picasaoriginals"

#----------------------------------------------------------------------------
def build_list_of_photo_dirs_with_junk(pdir):
    """Return list of photo directories containing picasa junk."""
    dir_list = []
    for dirpath, dirnames, files in os.walk(pdir):
        for d in dirnames:
            if ( d == keyword ):
                #print("Found one:  ", dirpath)
                dir_list.append(dirpath)
    return dir_list
#----------------------------------------------------------------------------
def check_for_multiple_layers_of_junk(pdir):
    """Look for multiple layers of junk for pdir, return True if found.

    Multiple layers can be:
    1) Any dirpath containing the .picasaoriginals folder AND other folders
    2) Any dirpath containing multiple layers of .picasaoriginals folders
    """

    for dirpath, dirnames, files in os.walk(pdir):

        # If there are 2 or more folders, and one is .picasaoriginals
        if len(dirnames) > 1 and keyword in dirnames:
            return True

        # If there are 2 or layers of .picasaoriginals
        if basename(dirpath) == keyword and keyword in dirnames:
            return True

    return False
#----------------------------------------------------------------------------
def confirm(prompt=None, resp=False):
    """Prompt user for yes or no response. Returns True for yes and False for no.

    "resp" should be set to the default value assumed by the caller when
    user simply types ENTER.

    Ex.
    >>> confirm( prompt="Create Directory?", resp=True )
    Create Directory? [y]|n:
    True
    >>> confirm(prompt="Create Directory?", resp=False)
    Create Directory? [n]|y:
    False
    >>> confirm(prompt="Create Directory?", resp=False)
    Create Directory? [n]|y: y
    True
    """

    if prompt is None:
        prompt = "Confirm"

    if resp:      # If default response is True, bracket the [y]
        prompt = "%s [%s]|%s: " % (prompt, "y", "n")
    else:        # If default response is True, bracket the [n]
        prompt = "%s [%s]|%s: " % (prompt, "n", "y")


    while True:
        ans = input(prompt)
        if not ans:
            return resp
        if ans not in ["y", "Y", "n", "N"]:
            print("please enter y or n.")
            continue
        if ans == "y" or ans == "Y":
            return True
        if ans == "n" or ans == "N":
            return False
#----------------------------------------------------------------------------
def zip_picasaoriginals_in_(photo_dir, sim=False):
    """Zip the .picasaoriginals/ folder and it's contents, plus the .picasa.ini file if
    present.  Returns name of new zip file on success, or False on failure.
    """
    # Setup variables with fixed names of picasa junk
    archive_file = join( photo_dir, ".picasa.zip" )
    pico_dir = join( photo_dir, ".picasaoriginals" )
    top_ini_file = join( photo_dir, ".picasa.ini" )

    # Print verbose messages to screen (modify to False to disable)
    if True:
        print("============  ZIP  ============")
        print("-  pico_dir:     ",pico_dir)
        print("-  top_ini_file: ",top_ini_file)
        print("-  archive:      ",archive_file)
        print("-------------------------------")

    # Double-check that .picasaoringals folder is actually here.
    # It should never be missing if the ignore_list and zippy_list are working.
    if isdir(pico_dir) is False:
        print("\nERROR: No .picasaoriginals/ folder here. Skipping.\n", pico_dir)
        return False

    # If simulation mode is True, don't create the .zip file
    if sim:
        print("**SIMULATION MODE**  (NOT) opening zip file", archive_file)
        if isfile( top_ini_file ):
            print("**SIMULATION MODE**  (NOT) adding", top_ini_file)
        for folder, subfolders, files in os.walk( pico_dir ):
            for file in files:
                print("**SIMULATION MODE**  (NOT) adding",  join(folder, file))
        return "simulated__"+archive_file

    # Create the zip archive and start adding the files
    print("opening zip file", archive_file)
    with ZipFile( archive_file, "w" ) as archive:
    ####
    ####
    ####    Testing APPEND mode
    #with ZipFile( archive_file, "a" ) as archive:
    ####
    ####    Nope.  We'll end up with duplicate names in the .zip.
    ####


        # Add the top-level picasa.ini if it exists
        if isfile( top_ini_file ):
            print("adding", top_ini_file)
            archive.write(
                    top_ini_file,   # abspath to top-level .picasa.ini file
                    ".picasa.ini",  # what to call it inside the .zip (no sub-dirs)
                    compress_type = ZIP_DEFLATED,   # Use compression
            )

        # Walk the tree below .picasaoriginals/ and add everything to the archive
        for folder, subfolders, files in os.walk( pico_dir ):

            for file in files:

                # Absolute path to file to be added
                abs_path_to_file = join(folder, file)

                # Relative path starting FROM the right place, photo_dir,
                # which is one level up from pico_dir
                rela_path_plus_file = relpath( join(folder,file), photo_dir )

                print("adding", abs_path_to_file)
                archive.write(
                    abs_path_to_file,       # Abspath of the file to be added
                    rela_path_plus_file,    # Relpath for storage inside the archive
                    compress_type = ZIP_DEFLATED
                )

    archive.close()  # should no be needed, but just in case
    return archive_file

#----------------------------------------------------------------------------
def delete_picasaoriginals_in_(photo_dir, sim=False):
    """Delete .picasaoriginals/* and .picasa.ini from photo_dir"""

    #photo_dir = "c:\\PhotosTest\\2020\\2015-07-20 - Outback Offroadin\\"
    archive_file = join( photo_dir, ".picasa.zip" )     # just in we want to check it
    pico_dir = join( photo_dir, ".picasaoriginals" )    # to be deleted
    top_ini_file = join( photo_dir, ".picasa.ini" )     # to be deleted

    if True:
        print("-----------DEL---------")

    # Make sure zip file exists before deleting
    if sim:
        print("**SIMULATION MODE** (Did NOT) create zip file", archive_file)
    elif isfile(archive_file) is False:
        print("Uh-oh. Something went wrong. There is no zip file\n", archive_file)
        return False


    # Test if the pico_dir still exists.  If not, something went horribly wrong.
    if isdir(pico_dir) is False:
        print("Uh-oh. Something went wrong. Dir to delete no longer exists.")
        print(pico_dir)
        return False
    # Check permissions allow write (delete)
    elif os.access(pico_dir, os.W_OK) is False:
        print("Uh-oh. Don't have permission to delete dir:\n", pico_dir)
        return False
    elif sim:
        print("**SIMULATION MODE**  (NOT) deleting", pico_dir)
    else:
        print("DELETING", pico_dir)
        rmtree(pico_dir)



    # Test if the .picasa.ini file exists
    # Since this file is optional, no need to cause alarm if it does not exist
    if isfile(top_ini_file) is False:
        print("There is no ini file to delete here")
        # do not return anything since ini is optional
    elif os.access(top_ini_file, os.W_OK) is False:
        print("Uh-oh. Don't have permission to delete ini:",top_ini_file)
        # do not return anything since ini is optional
    elif sim:
        print("**SIMULATION MODE**  (NOT) deleting", top_ini_file)
    else:
        print("DELETING", top_ini_file)
        os.remove( top_ini_file )
        # do not return anything since ini is optional

    return True

#---------------------------------------------------------------------------
def restore():
    fresh_data = "c:\\PhotosTestUntouched\\"
    test_data  = "c:\\PhotosTest\\"

    print(f"Restoring data from {fresh_data} to {test_data} ...")
    if isdir(test_data):
        print("\nFirst, delete the existing test_data")
        rmtree(test_data)
        print("OK")
    else:
        print("\nTest_data does not exist.. continue.")

    print("\nThen, copy the fresh data to test data")
    copytree(fresh_data, test_data)
    print("OK")
    print("\nDone\n")

#---------------------------------------------------------------------------
def countdown(t):
    while t:
        mins, secs = divmod(t, 60)
        timeformat = "{:02d}:{:02d}".format(mins, secs)
        print(timeformat, end="\r")
        time.sleep(1)
        t -= 1
    print("Blastoff!!!\n\n")

#---------------------------------------------------------------------------
def countdown_in_sec(s):
    while s:
        timeformat = "{:02d}".format(s)
        print(f"{timeformat} -> ", end="\r",flush=True)
        time.sleep(1)
        s -= 1
    print("Blastoff!!!\n\n")
    time.sleep(.75)

#---------------------------------------------------------------------------



if __name__ == "__main__":
   print()